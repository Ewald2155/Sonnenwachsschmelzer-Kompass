
/*
  Dini Bee Sonnenwachsschmelzer - SolarTracker Vers.2026_13_MMC5603
  ------------------------------------------------------------------
  Neue Kompass-Version fuer Arduino Nano.

  Grundidee:
  - Nur noch EIN Lichtsensor wird verwendet: A1, nach oben ausgerichtet.
  - Die Tag-/Nachtschaltung ist weiterhin vorhanden: A1 baut ueber eine
    einstellbare Freigabe-Rampe die Steuerfreigabe auf oder ab.
  - Zusaetzlich begrenzt die DS3231 das Arbeitszeitfenster jetzt standardmaessig
    auf 10:00 bis 17:00 Uhr.
  - A0 und A2 bleiben frei / Reserve.
  - Die Ausrichtung erfolgt ueber den Adafruit MMC5603 Magnetometer/Kompass.
  - Die Sollrichtung der Sonne wird aus Datum/Uhrzeit der DS3231 und dem
    festen Standort 8541 Bad Schwanberg berechnet.
  - Motor, LCD, Encoder, EEPROM-Schutz und Bootloader-sicherer Start bleiben
    vom bisherigen Projektprinzip erhalten.

  Benoetigte Arduino-Bibliotheken:
  - Wire
  - EEPROM
  - LiquidCrystal_I2C
  - RTClib von Adafruit
  - Adafruit MMC56x3
  - Adafruit Unified Sensor
*/

#include <Wire.h>
#include <EEPROM.h>
#include <LiquidCrystal_I2C.h>
#include <RTClib.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_MMC56x3.h>
#include <math.h>

// ------------------------- Version / Standort -------------------------
#define VERSION_TEXT "Vers.2026_13_MMC"
#define CONFIG_MAGIC 0xD1BEE23DUL
#define CONFIG_VERSION 202613

// Standort 8541 Bad Schwanberg, Steiermark, gerundet.
const float SITE_LATITUDE  = 46.7569f;   // Nord
const float SITE_LONGITUDE = 15.2000f;   // Ost

// ------------------------- Pinbelegung Arduino Nano --------------------
const byte PIN_LDR_LIGHT      = A1;  // einziger LDR, nach oben gerichtet
const byte PIN_A0_RESERVE     = A0;  // frei / Reserve
const byte PIN_A2_RESERVE     = A2;  // frei / Reserve
const byte PIN_SYS_ENABLE     = A3;  // INPUT_PULLUP: offen/HIGH = EIN, GND = AUS

const byte PIN_MOTOR_LPWM     = 5;   // BTS7960 L_PWM, PWM
const byte PIN_MOTOR_RPWM     = 6;   // BTS7960 R_PWM, PWM
const byte PIN_MOTOR_ENABLE   = 7;   // BTS7960 Enable oder Enable-Schaltstufe
const byte PIN_D8_RESERVE     = 8;   // frei / fuer spaetere Warnleuchte reserviert

const byte PIN_ENC1_CLK       = 2;   // Encoder 1 CLK, Interrupt
const byte PIN_ENC1_DT        = 4;   // Encoder 1 DT
const byte PIN_ENC1_SW        = 9;   // Encoder 1 Taster
const byte PIN_ENC2_CLK       = 3;   // Encoder 2 CLK, Interrupt
const byte PIN_ENC2_DT        = 10;  // Encoder 2 DT
const byte PIN_ENC2_SW        = 11;  // Encoder 2 Taster

const byte PIN_STATUS_LED     = 13;  // Status-LED

// I2C: A4 = SDA, A5 = SCL fuer LCD + RTC + Adafruit MMC5603
const byte LCD_ADDR = 0x27;

// Adafruit MMC5603 Standard-I2C-Adresse ist 0x30.
Adafruit_MMC5603 mmc = Adafruit_MMC5603(12345);
RTC_DS3231 rtc;
LiquidCrystal_I2C lcd(LCD_ADDR, 20, 4);

// ------------------------- Konfiguration im EEPROM ---------------------
struct ConfigData {
  uint32_t magic;
  uint32_t version;

  uint16_t lightOnThreshold;    // LDR-Wert: ab hier Freigabe hochzaehlen
  uint16_t lightOffThreshold;   // LDR-Wert: darunter Freigabe herunterzaehlen
  uint16_t lightRampUpSec;      // Sekunden bis 100 % Freigabe
  uint16_t lightRampDownSec;    // Sekunden bis 0 % Freigabe

  byte motorMinPwm;
  byte motorMaxPwm;
  byte motorFinePwm;
  uint16_t rampTimeMs;

  byte angleToleranceDeg;       // Zielbereich: keine Bewegung
  byte fineRangeDeg;            // unter diesem Fehler nur kurze Feinschritte
  uint16_t coarsePulseMs;       // Motorimpuls bei grossem Fehler
  uint16_t midPulseMs;          // Motorimpuls bei mittlerem Fehler
  uint16_t finePulseMs;         // Motorimpuls bei kleinem Fehler
  uint16_t measurePauseMs;      // Wartezeit nach Motorimpuls vor Messung
  uint16_t reversePulseMs;      // kurzer Retourimpuls bei Uebersteuern

  int16_t compassOffsetDeg;     // Montageabgleich: korrigierter Winkel = Rohwinkel + Offset
  int16_t solarOffsetDeg;       // Feinkorrektur der berechneten Sonnenrichtung
  int8_t motorPolarity;         // +1: R_PWM erhoeht Winkel, -1: R_PWM senkt Winkel
  byte compassReverse;          // 0 normal, 1 Kompasswinkel gespiegelt

  byte dayStartHour;
  byte dayStartMinute;
  byte dayStopHour;
  byte dayStopMinute;
  byte dstMode;                 // 0 Winterzeit MEZ, 1 Sommerzeit MESZ, 2 Auto EU

  byte lcdTimeoutMin;
  byte lcdBacklightPct;         // 0=aus, >0=ein; I2C-Backpack kann meist nur EIN/AUS
};

ConfigData cfg;

// ------------------------- Laufende Messwerte --------------------------
int ldrRaw = 0;
float ldrFiltered = 0.0f;
byte lightGatePct = 0;
bool lightArmed = false;

bool rtcOk = false;
bool compassOk = false;
bool compassDisturbed = false;

float headingRawDeg = 0.0f;
float headingDeg = 0.0f;
float targetDeg = 0.0f;
float errorDeg = 0.0f;
float lastErrorBeforePulse = 999.0f;
int lastPulseDir = 0;

// ------------------------- Motorzustand --------------------------------
int motorTargetDir = 0;     // logisch: +1 = Winkel soll steigen, -1 = Winkel soll fallen
byte motorTargetPwm = 0;
byte motorCurrentPwm = 0;
int motorCurrentDir = 0;
unsigned long lastMotorRampMs = 0;

// Impuls-Zustandsmaschine fuer ruhige Kompassmessung.
enum TrackState : byte {
  TRACK_IDLE,
  TRACK_PULSE,
  TRACK_PAUSE,
  TRACK_REVERSE
};
TrackState trackState = TRACK_IDLE;
unsigned long stateUntilMs = 0;
unsigned long lastGoodMoveMs = 0;
byte badMoveCounter = 0;

// ------------------------- Menue / Encoder -----------------------------
volatile int8_t enc1Delta = 0;
volatile int8_t enc2Delta = 0;
volatile byte enc1Prev = 0;
volatile byte enc2Prev = 0;

bool inMenu = false;
bool editMode = false;
byte menuIndex = 0;
byte editField = 0;
const byte MENU_COUNT = 11;
unsigned long lastUserMs = 0;
const unsigned long MENU_AUTO_RETURN_MS = 10000UL;

bool enc1SwLast = HIGH;
bool enc2SwLast = HIGH;
unsigned long enc1SwChangeMs = 0;
unsigned long enc2SwChangeMs = 0;
unsigned long enc1PressStartMs = 0;
bool enc1LongDone = false;

uint16_t rtcEditYear = 2026;
byte rtcEditMonth = 1;
byte rtcEditDay = 1;
byte rtcEditHour = 12;
byte rtcEditMinute = 0;
bool rtcEditLoaded = false;

// LCD-Zeilencache gegen Flackern.
char lcdCache[4][21];
bool lcdReady = false;
bool lcdBacklightOn = true;

// Statusanzeige.
enum StatusCode : byte {
  ST_START,
  ST_SYS_OFF,
  ST_TOO_DARK,
  ST_LIGHT_RAMP,
  ST_COMPASS_MISSING,
  ST_RTC_MISSING,
  ST_TARGET_OK,
  ST_COARSE,
  ST_FINE,
  ST_REVERSE,
  ST_MENU,
  ST_CAL_SAVED,
  ST_MOTOR_TEST,
  ST_COMPASS_DISTURB
};
StatusCode statusCode = ST_START;


// Forward declarations for normal C++ and Arduino preprocessors.
void renderDisplay();
void resetTracking();
void stopMotor();
void saveConfig();
bool readCompass();
void loadRtcEdit();
void saveRtcEdit();

// ------------------------- Hilfsfunktionen -----------------------------
float norm360(float a) {
  while (a < 0.0f) a += 360.0f;
  while (a >= 360.0f) a -= 360.0f;
  return a;
}

float angleDiff(float target, float current) {
  float d = target - current;
  while (d > 180.0f) d -= 360.0f;
  while (d < -180.0f) d += 360.0f;
  return d;
}

int clampInt(int v, int lo, int hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

void makeLine(char *buf, const char *text) {
  byte i = 0;
  while (i < 20 && text[i]) {
    buf[i] = text[i];
    i++;
  }
  while (i < 20) buf[i++] = ' ';
  buf[20] = '\0';
}

void lcdPrintLine(byte row, const char *text) {
  if (!lcdReady) return;
  char line[21];
  makeLine(line, text);
  if (strncmp(lcdCache[row], line, 20) != 0) {
    lcd.setCursor(0, row);
    lcd.print(line);
    memcpy(lcdCache[row], line, 21);
  }
}

void lcdInvalidate() {
  for (byte r = 0; r < 4; r++) {
    for (byte c = 0; c < 20; c++) lcdCache[r][c] = '\0';
    lcdCache[r][20] = '\0';
  }
}

void wakeDisplay() {
  lastUserMs = millis();
  if (!lcdBacklightOn) {
    lcd.backlight();
    lcdBacklightOn = true;
    lcdInvalidate();
  }
}

void updateBacklightTimeout() {
  if (!lcdReady) return;
  if (cfg.lcdTimeoutMin == 0) return;
  if (lcdBacklightOn && millis() - lastUserMs > (unsigned long)cfg.lcdTimeoutMin * 60000UL) {
    lcd.noBacklight();
    lcdBacklightOn = false;
  }
}

const char *statusText() {
  switch (statusCode) {
    case ST_SYS_OFF: return "SYS AUS";
    case ST_TOO_DARK: return "Zu dunkel";
    case ST_LIGHT_RAMP: return "Licht Rampe";
    case ST_COMPASS_MISSING: return "Kompass fehlt";
    case ST_RTC_MISSING: return "RTC fehlt";
    case ST_TARGET_OK: return "Ziel erreicht";
    case ST_COARSE: return "Grobfahrt";
    case ST_FINE: return "Feinfahrt";
    case ST_REVERSE: return "Retour";
    case ST_MENU: return "Menue Pause";
    case ST_CAL_SAVED: return "Abgleich OK";
    case ST_MOTOR_TEST: return "Motortest";
    case ST_COMPASS_DISTURB: return "Kompass Stoer";
    default: return "Start";
  }
}

// ------------------------- EEPROM --------------------------------------
void setDefaults() {
  cfg.magic = CONFIG_MAGIC;
  cfg.version = CONFIG_VERSION;
  cfg.lightOnThreshold = 700;
  cfg.lightOffThreshold = 550;
  cfg.lightRampUpSec = 30;
  cfg.lightRampDownSec = 90;
  cfg.motorMinPwm = 70;
  cfg.motorMaxPwm = 155;
  cfg.motorFinePwm = 90;
  cfg.rampTimeMs = 900;
  cfg.angleToleranceDeg = 5;
  cfg.fineRangeDeg = 15;
  cfg.coarsePulseMs = 700;
  cfg.midPulseMs = 350;
  cfg.finePulseMs = 140;
  cfg.measurePauseMs = 450;
  cfg.reversePulseMs = 120;
  cfg.compassOffsetDeg = 0;
  cfg.solarOffsetDeg = 0;
  cfg.motorPolarity = 1;
  cfg.compassReverse = 0;
  cfg.dayStartHour = 10;
  cfg.dayStartMinute = 0;
  cfg.dayStopHour = 17;
  cfg.dayStopMinute = 0;
  cfg.dstMode = 2;
  cfg.lcdTimeoutMin = 10;
  cfg.lcdBacklightPct = 100;
}

void saveConfig() {
  byte *p = (byte *)&cfg;
  for (unsigned int i = 0; i < sizeof(ConfigData); i++) {
    EEPROM.update(i, p[i]);
  }
  statusCode = ST_CAL_SAVED;
}

void loadConfig() {
  EEPROM.get(0, cfg);
  if (cfg.magic != CONFIG_MAGIC || cfg.version != CONFIG_VERSION) {
    setDefaults();
    // Absichtlich nicht automatisch schreiben: EEPROM-Schutz.
  }
  if (cfg.motorPolarity != 1 && cfg.motorPolarity != -1) cfg.motorPolarity = 1;
}

// ------------------------- Encoder -------------------------------------
byte readEncState(byte clkPin, byte dtPin) {
  return ((digitalRead(clkPin) ? 1 : 0) << 1) | (digitalRead(dtPin) ? 1 : 0);
}

int8_t quadStep(byte prev, byte now) {
  // Robuste kleine Quadraturtabelle. Ungueltige Prellspruenge ergeben 0.
  const int8_t table[16] = {0,-1,1,0, 1,0,0,-1, -1,0,0,1, 0,1,-1,0};
  return table[(prev << 2) | now];
}

void enc1ISR() {
  byte s = readEncState(PIN_ENC1_CLK, PIN_ENC1_DT);
  int8_t st = quadStep(enc1Prev, s);
  enc1Prev = s;
  enc1Delta += st;
}

void enc2ISR() {
  byte s = readEncState(PIN_ENC2_CLK, PIN_ENC2_DT);
  int8_t st = quadStep(enc2Prev, s);
  enc2Prev = s;
  enc2Delta += st;
}

void pollEncodersAlso() {
  byte s1 = readEncState(PIN_ENC1_CLK, PIN_ENC1_DT);
  if (s1 != enc1Prev) {
    noInterrupts();
    int8_t st = quadStep(enc1Prev, s1);
    enc1Prev = s1;
    enc1Delta += st;
    interrupts();
  }
  byte s2 = readEncState(PIN_ENC2_CLK, PIN_ENC2_DT);
  if (s2 != enc2Prev) {
    noInterrupts();
    int8_t st = quadStep(enc2Prev, s2);
    enc2Prev = s2;
    enc2Delta += st;
    interrupts();
  }
}

int8_t consumeEncoder(volatile int8_t &delta) {
  noInterrupts();
  int8_t d = delta;
  delta = 0;
  interrupts();
  if (d > 2) return 1;
  if (d < -2) return -1;
  return 0;
}

// ------------------------- RTC / Sonnenrichtung ------------------------
bool isLeap(int y) {
  return ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0));
}

int dayOfYear(const DateTime &dt) {
  static const uint16_t daysBeforeMonth[] = {0,0,31,59,90,120,151,181,212,243,273,304,334};
  int n = daysBeforeMonth[dt.month()] + dt.day();
  if (dt.month() > 2 && isLeap(dt.year())) n++;
  return n;
}

byte weekdayYMD(int y, byte m, byte d) {
  // 0 = Sonntag, 1 = Montag ... 6 = Samstag
  if (m < 3) { m += 12; y--; }
  int K = y % 100;
  int J = y / 100;
  int h = (d + 13 * (m + 1) / 5 + K + K / 4 + J / 4 + 5 * J) % 7;
  return (h + 6) % 7;
}

byte lastSunday(int y, byte month) {
  byte d = 31;
  while (weekdayYMD(y, month, d) != 0) d--;
  return d;
}

byte utcOffsetHours(const DateTime &dt) {
  if (cfg.dstMode == 0) return 1; // MEZ
  if (cfg.dstMode == 1) return 2; // MESZ
  // Auto EU: grob fuer lokale Zeit. Reicht fuer die Sonnenrichtung im Projekt.
  int y = dt.year();
  byte m = dt.month();
  byte d = dt.day();
  if (m < 3 || m > 10) return 1;
  if (m > 3 && m < 10) return 2;
  byte marchLast = lastSunday(y, 3);
  byte octLast = lastSunday(y, 10);
  if (m == 3) return (d >= marchLast) ? 2 : 1;
  if (m == 10) return (d < octLast) ? 2 : 1;
  return 1;
}

bool timeWindowActive(const DateTime &dt) {
  int nowMin = dt.hour() * 60 + dt.minute();
  int startMin = cfg.dayStartHour * 60 + cfg.dayStartMinute;
  int stopMin = cfg.dayStopHour * 60 + cfg.dayStopMinute;
  if (startMin <= stopMin) return nowMin >= startMin && nowMin < stopMin;
  return nowMin >= startMin || nowMin < stopMin;
}

float calcSolarAzimuth(const DateTime &dt) {
  // Kompakte NOAA-Naeherung. Ergebnis: Grad im Uhrzeigersinn ab geografisch Nord.
  int n = dayOfYear(dt);
  float localHour = dt.hour() + dt.minute() / 60.0f + dt.second() / 3600.0f;
  float gamma = 2.0f * PI / 365.0f * ((float)n - 1.0f + (localHour - 12.0f) / 24.0f);

  float eqtime = 229.18f * (0.000075f + 0.001868f * cos(gamma) - 0.032077f * sin(gamma)
                 - 0.014615f * cos(2.0f * gamma) - 0.040849f * sin(2.0f * gamma));
  float decl = 0.006918f - 0.399912f * cos(gamma) + 0.070257f * sin(gamma)
               - 0.006758f * cos(2.0f * gamma) + 0.000907f * sin(2.0f * gamma)
               - 0.002697f * cos(3.0f * gamma) + 0.00148f * sin(3.0f * gamma);

  float timeOffset = eqtime + 4.0f * SITE_LONGITUDE - 60.0f * (float)utcOffsetHours(dt);
  float trueSolarTime = dt.hour() * 60.0f + dt.minute() + dt.second() / 60.0f + timeOffset;
  while (trueSolarTime < 0.0f) trueSolarTime += 1440.0f;
  while (trueSolarTime >= 1440.0f) trueSolarTime -= 1440.0f;

  float hourAngleDeg = trueSolarTime / 4.0f - 180.0f;
  float ha = hourAngleDeg * PI / 180.0f;
  float lat = SITE_LATITUDE * PI / 180.0f;

  float az = atan2(sin(ha), cos(ha) * sin(lat) - tan(decl) * cos(lat));
  float azDeg = az * 180.0f / PI + 180.0f;
  return norm360(azDeg + (float)cfg.solarOffsetDeg);
}

// ------------------------- Sensoren ------------------------------------
void readLightSensor() {
  ldrRaw = analogRead(PIN_LDR_LIGHT);
  if (ldrFiltered <= 1.0f) ldrFiltered = (float)ldrRaw;
  // 0.12 = ruhige Glaettung, aber noch ausreichend schnell fuer Helligkeitsfreigabe.
  ldrFiltered = ldrFiltered * 0.88f + (float)ldrRaw * 0.12f;
}

void updateLightGate() {
  static unsigned long lastMs = 0;
  unsigned long now = millis();
  if (lastMs == 0) lastMs = now;
  unsigned long dt = now - lastMs;
  lastMs = now;

  int stepUpDen = max(1, (int)cfg.lightRampUpSec * 1000);
  int stepDownDen = max(1, (int)cfg.lightRampDownSec * 1000);

  if ((int)ldrFiltered >= cfg.lightOnThreshold) {
    int add = (int)((dt * 100UL) / (unsigned long)stepUpDen);
    if (add < 1 && dt > 0) add = 1;
    lightGatePct = (byte)clampInt((int)lightGatePct + add, 0, 100);
  } else if ((int)ldrFiltered <= cfg.lightOffThreshold) {
    int sub = (int)((dt * 100UL) / (unsigned long)stepDownDen);
    if (sub < 1 && dt > 0) sub = 1;
    lightGatePct = (byte)clampInt((int)lightGatePct - sub, 0, 100);
  }
  lightArmed = (lightGatePct >= 100);
}

bool readCompass() {
  sensors_event_t event;
  if (!mmc.getEvent(&event)) return false;

  float x = event.magnetic.x;
  float y = event.magnetic.y;
  float z = event.magnetic.z;
  float mag = sqrt(x * x + y * y + z * z);
  compassDisturbed = (mag < 5.0f || mag > 120.0f); // nur grobe Plausibilitaet

  float h = atan2(y, x) * 180.0f / PI;
  h = norm360(h);
  if (cfg.compassReverse) h = norm360(360.0f - h);

  headingRawDeg = h;
  headingDeg = norm360(h + (float)cfg.compassOffsetDeg);
  return true;
}

// ------------------------- Motor ---------------------------------------
void lowLevelMotorWrite(int physicalDir, byte pwm) {
  if (pwm == 0 || physicalDir == 0) {
    analogWrite(PIN_MOTOR_LPWM, 0);
    analogWrite(PIN_MOTOR_RPWM, 0);
    digitalWrite(PIN_MOTOR_ENABLE, LOW);
    return;
  }
  digitalWrite(PIN_MOTOR_ENABLE, HIGH);
  if (physicalDir > 0) {
    analogWrite(PIN_MOTOR_LPWM, 0);
    analogWrite(PIN_MOTOR_RPWM, pwm);
  } else {
    analogWrite(PIN_MOTOR_RPWM, 0);
    analogWrite(PIN_MOTOR_LPWM, pwm);
  }
}

void setMotorTarget(int logicalDir, byte pwm) {
  motorTargetDir = logicalDir;
  motorTargetPwm = pwm;
  if (logicalDir == 0 || pwm == 0) motorTargetPwm = 0;
  if (motorTargetPwm > cfg.motorMaxPwm) motorTargetPwm = cfg.motorMaxPwm;
}

void stopMotor() {
  setMotorTarget(0, 0);
}

void updateMotorRamp() {
  unsigned long now = millis();
  if (lastMotorRampMs == 0) lastMotorRampMs = now;
  unsigned long dt = now - lastMotorRampMs;
  if (dt < 20) return;
  lastMotorRampMs = now;

  if (motorTargetDir != 0 && motorCurrentDir != motorTargetDir && motorCurrentPwm > 0) {
    // Richtungswechsel erst nach Abbremsen.
    motorTargetPwm = 0;
  }

  int step = (int)((dt * 255UL) / max(1, (int)cfg.rampTimeMs));
  if (step < 1) step = 1;

  if (motorCurrentPwm < motorTargetPwm) {
    if (motorCurrentPwm == 0) {
      int startPwm = max((int)cfg.motorMinPwm, (int)motorTargetPwm / 2);
      motorCurrentPwm = (byte)clampInt(startPwm, 0, motorTargetPwm);
      motorCurrentDir = motorTargetDir;
    } else {
      motorCurrentPwm = (byte)min((int)motorTargetPwm, (int)motorCurrentPwm + step);
    }
  } else if (motorCurrentPwm > motorTargetPwm) {
    motorCurrentPwm = (byte)max((int)motorTargetPwm, (int)motorCurrentPwm - step);
    if (motorCurrentPwm == 0) motorCurrentDir = 0;
  }

  int physicalDir = motorCurrentDir * (int)cfg.motorPolarity;
  lowLevelMotorWrite(physicalDir, motorCurrentPwm);
}

// ------------------------- Regelung ------------------------------------
void resetTracking() {
  trackState = TRACK_IDLE;
  stopMotor();
  lastErrorBeforePulse = 999.0f;
  lastPulseDir = 0;
  badMoveCounter = 0;
}

void startPulse(int logicalDir, byte pwm, uint16_t durMs, TrackState nextState) {
  lastErrorBeforePulse = errorDeg;
  lastPulseDir = logicalDir;
  setMotorTarget(logicalDir, pwm);
  trackState = nextState;
  stateUntilMs = millis() + durMs;
}

void updateTracking() {
  DateTime nowDt;
  if (rtcOk) nowDt = rtc.now();

  bool sysOn = (digitalRead(PIN_SYS_ENABLE) == HIGH);
  if (!sysOn) { statusCode = ST_SYS_OFF; resetTracking(); return; }

  if (!rtcOk) {
    statusCode = ST_RTC_MISSING;
    // Zur Sicherheit trotzdem weiter, aber ohne Zeitfenster/Sonnenberechnung waere nur Handbetrieb sinnvoll.
    resetTracking();
    return;
  }

  if (!timeWindowActive(nowDt)) { statusCode = ST_TOO_DARK; resetTracking(); return; }

  if (!lightArmed) {
    statusCode = (lightGatePct == 0) ? ST_TOO_DARK : ST_LIGHT_RAMP;
    resetTracking();
    return;
  }

  if (!compassOk) { statusCode = ST_COMPASS_MISSING; resetTracking(); return; }
  if (compassDisturbed) { statusCode = ST_COMPASS_DISTURB; resetTracking(); return; }

  targetDeg = calcSolarAzimuth(nowDt);
  errorDeg = angleDiff(targetDeg, headingDeg);
  float absErr = fabs(errorDeg);

  if (absErr <= (float)cfg.angleToleranceDeg) {
    statusCode = ST_TARGET_OK;
    resetTracking();
    return;
  }

  unsigned long now = millis();

  if (trackState == TRACK_PULSE || trackState == TRACK_REVERSE) {
    // Waerend der Bewegung live beobachten: Wenn das Ziel ueberschritten wurde,
    // Impuls sofort abbrechen. Danach wird in Ruhe neu gemessen.
    float liveErr = angleDiff(targetDeg, headingDeg);
    if ((lastErrorBeforePulse > 0.0f && liveErr < -(float)cfg.angleToleranceDeg) ||
        (lastErrorBeforePulse < 0.0f && liveErr >  (float)cfg.angleToleranceDeg)) {
      stopMotor();
      trackState = TRACK_PAUSE;
      stateUntilMs = now + cfg.measurePauseMs;
      statusCode = ST_REVERSE;
      return;
    }
    if ((long)(now - stateUntilMs) >= 0) {
      stopMotor();
      trackState = TRACK_PAUSE;
      stateUntilMs = now + cfg.measurePauseMs;
    }
    return;
  }

  if (trackState == TRACK_PAUSE) {
    stopMotor();
    if ((long)(now - stateUntilMs) < 0) return;
    float newAbs = fabs(errorDeg);
    float oldAbs = fabs(lastErrorBeforePulse);

    // Wenn ein Impuls eindeutig schlechter wurde, wird ein sehr kurzer Retourimpuls gesetzt.
    if (oldAbs < 998.0f && newAbs > oldAbs + 3.0f) {
      badMoveCounter++;
      int backDir = (errorDeg > 0.0f) ? 1 : -1;
      statusCode = ST_REVERSE;
      startPulse(backDir, cfg.motorFinePwm, cfg.reversePulseMs, TRACK_REVERSE);
      return;
    }
    if (newAbs < oldAbs) {
      badMoveCounter = 0;
      lastGoodMoveMs = now;
    }
    trackState = TRACK_IDLE;
  }

  // Neuer Impuls nach aktuellem Winkelfehler.
  int dir = (errorDeg > 0.0f) ? 1 : -1;
  if (absErr > 25.0f) {
    statusCode = ST_COARSE;
    startPulse(dir, cfg.motorMaxPwm, cfg.coarsePulseMs, TRACK_PULSE);
  } else if (absErr > (float)cfg.fineRangeDeg) {
    statusCode = ST_COARSE;
    byte pwm = (byte)((cfg.motorMaxPwm + cfg.motorFinePwm) / 2);
    startPulse(dir, pwm, cfg.midPulseMs, TRACK_PULSE);
  } else {
    statusCode = ST_FINE;
    startPulse(dir, cfg.motorFinePwm, cfg.finePulseMs, TRACK_PULSE);
  }
}

// ------------------------- Kalibrierungen ------------------------------
void setCompassAlignmentToSun() {
  if (!rtcOk || !compassOk) return;
  DateTime dt = rtc.now();
  float solar = calcSolarAzimuth(dt);
  float raw = headingRawDeg;
  cfg.compassOffsetDeg = (int16_t)round(angleDiff(solar, raw));
  saveConfig();
  headingDeg = norm360(raw + cfg.compassOffsetDeg);
  statusCode = ST_CAL_SAVED;
}

void runMotorDirectionTest() {
  if (!compassOk) return;
  statusCode = ST_MOTOR_TEST;
  wakeDisplay();
  renderDisplay();
  float before = headingDeg;
  // Roh Richtung R_PWM testen, ohne cfg.motorPolarity zu verwenden.
  digitalWrite(PIN_MOTOR_ENABLE, HIGH);
  analogWrite(PIN_MOTOR_LPWM, 0);
  analogWrite(PIN_MOTOR_RPWM, cfg.motorFinePwm);
  delay(500);
  analogWrite(PIN_MOTOR_RPWM, 0);
  digitalWrite(PIN_MOTOR_ENABLE, LOW);
  delay(700);
  readCompass();
  float after = headingDeg;
  float d = angleDiff(after, before);
  cfg.motorPolarity = (d >= 0.0f) ? 1 : -1;
  saveConfig();
  resetTracking();
}


void loadRtcEdit() {
  if (!rtcOk) return;
  DateTime dt = rtc.now();
  rtcEditYear = dt.year();
  rtcEditMonth = dt.month();
  rtcEditDay = dt.day();
  rtcEditHour = dt.hour();
  rtcEditMinute = dt.minute();
  rtcEditLoaded = true;
}

byte daysInMonth(uint16_t y, byte m) {
  static const byte dim[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
  if (m == 2 && isLeap(y)) return 29;
  if (m >= 1 && m <= 12) return dim[m];
  return 31;
}

void saveRtcEdit() {
  if (!rtcOk) return;
  byte maxDay = daysInMonth(rtcEditYear, rtcEditMonth);
  if (rtcEditDay > maxDay) rtcEditDay = maxDay;
  rtc.adjust(DateTime(rtcEditYear, rtcEditMonth, rtcEditDay, rtcEditHour, rtcEditMinute, 0));
  statusCode = ST_CAL_SAVED;
}

// ------------------------- Menue ---------------------------------------
void startMenu() {
  inMenu = true;
  editMode = false;
  editField = 0;
  rtcEditLoaded = false;
  menuIndex = 0;
  resetTracking();
  wakeDisplay();
}

void leaveMenu() {
  inMenu = false;
  editMode = false;
  editField = 0;
  rtcEditLoaded = false;
  wakeDisplay();
}

void adjustCurrentField(int8_t step) {
  if (step == 0) return;
  switch (menuIndex) {
    case 1: // Lichtfreigabe
      if (editField == 0) cfg.lightOnThreshold = clampInt(cfg.lightOnThreshold + step * 10, 100, 1000);
      else if (editField == 1) cfg.lightOffThreshold = clampInt(cfg.lightOffThreshold + step * 10, 50, cfg.lightOnThreshold - 20);
      else if (editField == 2) cfg.lightRampUpSec = clampInt(cfg.lightRampUpSec + step * 5, 0, 600);
      else cfg.lightRampDownSec = clampInt(cfg.lightRampDownSec + step * 5, 0, 900);
      break;
    case 3: // Ausrichtung setzen
      if (editField == 0 && step != 0) setCompassAlignmentToSun();
      break;
    case 4: // Motorwerte
      if (editField == 0) cfg.motorMinPwm = clampInt(cfg.motorMinPwm + step * 5, 0, 255);
      else if (editField == 1) cfg.motorMaxPwm = clampInt(cfg.motorMaxPwm + step * 5, cfg.motorMinPwm, 255);
      else if (editField == 2) cfg.motorFinePwm = clampInt(cfg.motorFinePwm + step * 5, cfg.motorMinPwm, cfg.motorMaxPwm);
      else cfg.rampTimeMs = clampInt(cfg.rampTimeMs + step * 100, 100, 5000);
      break;
    case 5: // Winkelregelung
      if (editField == 0) cfg.angleToleranceDeg = clampInt(cfg.angleToleranceDeg + step, 1, 20);
      else if (editField == 1) cfg.fineRangeDeg = clampInt(cfg.fineRangeDeg + step, cfg.angleToleranceDeg + 1, 45);
      else if (editField == 2) cfg.coarsePulseMs = clampInt(cfg.coarsePulseMs + step * 50, 100, 2500);
      else cfg.finePulseMs = clampInt(cfg.finePulseMs + step * 20, 50, 1000);
      break;
    case 6: // Motortest
      if (editField == 0 && step != 0) runMotorDirectionTest();
      break;
    case 7: // Zeitfenster
      if (editField == 0) cfg.dayStartHour = clampInt(cfg.dayStartHour + step, 0, 23);
      else if (editField == 1) cfg.dayStartMinute = clampInt(cfg.dayStartMinute + step * 5, 0, 55);
      else if (editField == 2) cfg.dayStopHour = clampInt(cfg.dayStopHour + step, 0, 23);
      else cfg.dayStopMinute = clampInt(cfg.dayStopMinute + step * 5, 0, 55);
      break;
    case 8: // RTC Zeit
      if (!rtcEditLoaded) loadRtcEdit();
      if (editField == 0) rtcEditYear = clampInt((int)rtcEditYear + step, 2024, 2035);
      else if (editField == 1) rtcEditMonth = clampInt((int)rtcEditMonth + step, 1, 12);
      else if (editField == 2) rtcEditDay = clampInt((int)rtcEditDay + step, 1, daysInMonth(rtcEditYear, rtcEditMonth));
      else if (editField == 3) rtcEditHour = clampInt((int)rtcEditHour + step, 0, 23);
      else rtcEditMinute = clampInt((int)rtcEditMinute + step * 5, 0, 55);
      break;
    case 9: // Kompass Optionen
      if (editField == 0) cfg.compassOffsetDeg = clampInt(cfg.compassOffsetDeg + step, -180, 180);
      else if (editField == 1) cfg.solarOffsetDeg = clampInt(cfg.solarOffsetDeg + step, -45, 45);
      else if (editField == 2) cfg.compassReverse = cfg.compassReverse ? 0 : 1;
      else cfg.dstMode = clampInt(cfg.dstMode + step, 0, 2);
      break;
    case 10: // LCD / EEPROM
      if (editField == 0) cfg.lcdTimeoutMin = clampInt(cfg.lcdTimeoutMin + step, 0, 60);
      else if (editField == 1) cfg.lcdBacklightPct = clampInt(cfg.lcdBacklightPct + step * 10, 0, 100);
      else if (editField == 2 && step != 0) saveConfig();
      break;
  }
}

byte fieldCountForMenu(byte idx) {
  switch (idx) {
    case 1: return 4;
    case 3: return 1;
    case 4: return 4;
    case 5: return 4;
    case 6: return 1;
    case 7: return 4;
    case 8: return 5;
    case 9: return 4;
    case 10: return 3;
  }
  return 0;
}

void handleButtons() {
  unsigned long now = millis();
  bool s1 = digitalRead(PIN_ENC1_SW);
  bool s2 = digitalRead(PIN_ENC2_SW);

  if (s1 != enc1SwLast && now - enc1SwChangeMs > 30) {
    enc1SwChangeMs = now;
    enc1SwLast = s1;
    if (s1 == LOW) {
      enc1PressStartMs = now;
      enc1LongDone = false;
      wakeDisplay();
    } else {
      if (!enc1LongDone) {
        if (!inMenu) startMenu(); else leaveMenu();
      }
    }
  }
  if (s1 == LOW && !enc1LongDone && now - enc1PressStartMs > 2000) {
    enc1LongDone = true;
    saveConfig();
    wakeDisplay();
  }

  if (s2 != enc2SwLast && now - enc2SwChangeMs > 30) {
    enc2SwChangeMs = now;
    enc2SwLast = s2;
    if (s2 == LOW) wakeDisplay();
    else {
      if (!inMenu) startMenu();
      else {
        byte fc = fieldCountForMenu(menuIndex);
        if (fc == 0) { editMode = false; }
        else if (!editMode) { editMode = true; editField = 0; if (menuIndex == 8) loadRtcEdit(); }
        else {
          editField++;
          if (editField >= fc) {
            if (menuIndex == 8) saveRtcEdit();
            editMode = false;
            editField = 0;
            saveConfig();
          }
        }
      }
    }
  }
}

void handleMenu() {
  pollEncodersAlso();
  handleButtons();

  int8_t d1 = consumeEncoder(enc1Delta);
  int8_t d2 = consumeEncoder(enc2Delta);
  if (d1 != 0 || d2 != 0) wakeDisplay();

  if (inMenu && !editMode && d1 != 0) {
    int n = (int)menuIndex + d1;
    if (n < 0) n = MENU_COUNT - 1;
    if (n >= MENU_COUNT) n = 0;
    menuIndex = (byte)n;
  }
  if (inMenu && editMode && d2 != 0) adjustCurrentField(d2);

  if (inMenu && millis() - lastUserMs > MENU_AUTO_RETURN_MS) leaveMenu();
}

// ------------------------- Display -------------------------------------
void formatDeg(char *buf, float v) {
  int iv = (int)round(norm360(v));
  snprintf(buf, 6, "%3d%c", iv, (char)223);
}

void renderStatus() {
  char l0[21], l1[21], l2[21], l3[21];
  char h[6], t[6];
  formatDeg(h, headingDeg);
  formatDeg(t, targetDeg);
  snprintf(l0, sizeof(l0), "Dini Bee Kompass");
  snprintf(l1, sizeof(l1), "Ist %s Soll %s", h, t);
  snprintf(l2, sizeof(l2), "LDR%4d Frei%3d%%", (int)ldrFiltered, lightGatePct);
  snprintf(l3, sizeof(l3), "%-13s E%4d", statusText(), (int)round(errorDeg));
  lcdPrintLine(0, l0);
  lcdPrintLine(1, l1);
  lcdPrintLine(2, l2);
  lcdPrintLine(3, l3);
}

void renderMenu() {
  char l0[21], l1[21], l2[21], l3[21];
  snprintf(l0, sizeof(l0), "Menue %02d/%02d %s", menuIndex + 1, MENU_COUNT, editMode ? "E" : " ");
  l1[0] = l2[0] = l3[0] = '\0';

  switch (menuIndex) {
    case 0:
      snprintf(l1, sizeof(l1), "Status anzeigen");
      snprintf(l2, sizeof(l2), "Enc1 zurueck");
      snprintf(l3, sizeof(l3), "%s", VERSION_TEXT);
      break;
    case 1:
      snprintf(l1, sizeof(l1), "Licht EIN %4u", cfg.lightOnThreshold);
      snprintf(l2, sizeof(l2), "AUS %4u Frei%3u%%", cfg.lightOffThreshold, lightGatePct);
      snprintf(l3, sizeof(l3), "Auf%3us Ab%3us", cfg.lightRampUpSec, cfg.lightRampDownSec);
      break;
    case 2:
      snprintf(l1, sizeof(l1), "Kompass Roh %3d", (int)headingRawDeg);
      snprintf(l2, sizeof(l2), "Korr %3d Ziel %3d", (int)headingDeg, (int)targetDeg);
      snprintf(l3, sizeof(l3), "Fehler %4d Grad", (int)round(errorDeg));
      break;
    case 3:
      snprintf(l1, sizeof(l1), "Ausrichtung setzen");
      snprintf(l2, sizeof(l2), "Handisch zur Sonne");
      snprintf(l3, sizeof(l3), "Enc2 drehen=speich");
      break;
    case 4:
      snprintf(l1, sizeof(l1), "PWM min%3u max%3u", cfg.motorMinPwm, cfg.motorMaxPwm);
      snprintf(l2, sizeof(l2), "Fein%3u Rampe", cfg.motorFinePwm);
      snprintf(l3, sizeof(l3), "%4u ms", cfg.rampTimeMs);
      break;
    case 5:
      snprintf(l1, sizeof(l1), "Tol %2u Fein %2u", cfg.angleToleranceDeg, cfg.fineRangeDeg);
      snprintf(l2, sizeof(l2), "Grob %4ums", cfg.coarsePulseMs);
      snprintf(l3, sizeof(l3), "Fein %4ums", cfg.finePulseMs);
      break;
    case 6:
      snprintf(l1, sizeof(l1), "Motor Richtung");
      snprintf(l2, sizeof(l2), "Polung: %s", cfg.motorPolarity > 0 ? "NORMAL" : "GEDREHT");
      snprintf(l3, sizeof(l3), "Enc2 drehen=Test");
      break;
    case 7:
      snprintf(l1, sizeof(l1), "Zeitfenster");
      snprintf(l2, sizeof(l2), "Start %02u:%02u", cfg.dayStartHour, cfg.dayStartMinute);
      snprintf(l3, sizeof(l3), "Stop  %02u:%02u", cfg.dayStopHour, cfg.dayStopMinute);
      break;
    case 8:
      if (!rtcEditLoaded) loadRtcEdit();
      snprintf(l1, sizeof(l1), "RTC Datum Zeit");
      snprintf(l2, sizeof(l2), "%04u-%02u-%02u", rtcEditYear, rtcEditMonth, rtcEditDay);
      snprintf(l3, sizeof(l3), "%02u:%02u speichern", rtcEditHour, rtcEditMinute);
      break;
    case 9:
      snprintf(l1, sizeof(l1), "KompOff %4d", cfg.compassOffsetDeg);
      snprintf(l2, sizeof(l2), "SonnOff %4d", cfg.solarOffsetDeg);
      snprintf(l3, sizeof(l3), "Rev %u DST %u", cfg.compassReverse, cfg.dstMode);
      break;
    case 10:
      snprintf(l1, sizeof(l1), "LCD Timeout %2u", cfg.lcdTimeoutMin);
      snprintf(l2, sizeof(l2), "Backlight %3u%%", cfg.lcdBacklightPct);
      snprintf(l3, sizeof(l3), "Speichern Enc2");
      break;
  }
  lcdPrintLine(0, l0);
  lcdPrintLine(1, l1);
  lcdPrintLine(2, l2);
  lcdPrintLine(3, l3);
}

void renderDisplay() {
  if (!lcdBacklightOn) return;
  if (inMenu) renderMenu(); else renderStatus();
}

void startText() {
  lcd.clear();
  lcd.setCursor(0, 0); lcd.print(F("Dini Bee Start"));
  lcd.setCursor(0, 1); lcd.print(F("LCD 20x4 OK"));
  lcd.setCursor(0, 2); lcd.print(F("Kompass MMC5603"));
  lcd.setCursor(0, 3); lcd.print(F("Bitte warten"));
  delay(1200);

  const char msg[] = "Dini Bee Sonnenwaxschmelzer Vers.2026_12_MMC5603";
  int len = strlen(msg);
  for (int pos = 20; pos > -len; pos--) {
    lcd.clear();
    lcd.setCursor(max(0, pos), 1);
    int start = (pos < 0) ? -pos : 0;
    for (int i = start; i < len && pos + i < 20; i++) lcd.print(msg[i]);
    delay(280);
  }
  lcd.clear();
  lcdInvalidate();
}

// ------------------------- LED -----------------------------------------
void updateStatusLed() {
  static unsigned long lastMs = 0;
  static byte phase = 0;
  unsigned long now = millis();

  if (statusCode == ST_COMPASS_DISTURB || statusCode == ST_COMPASS_MISSING) {
    if (now - lastMs >= 200) {
      lastMs = now;
      digitalWrite(PIN_STATUS_LED, !digitalRead(PIN_STATUS_LED));
    }
    return;
  }

  if (motorCurrentPwm > 0) {
    digitalWrite(PIN_STATUS_LED, HIGH);
    return;
  }

  if (lightArmed && digitalRead(PIN_SYS_ENABLE) == HIGH) {
    // alle 3 Sekunden 1 Sekunde EIN
    digitalWrite(PIN_STATUS_LED, (now % 3000UL) < 1000UL ? HIGH : LOW);
  } else {
    // alle 6 Sekunden zweimal kurz blinken
    unsigned long p = now % 6000UL;
    digitalWrite(PIN_STATUS_LED, (p < 150UL || (p > 350UL && p < 500UL)) ? HIGH : LOW);
  }
}

// ------------------------- Setup / Loop --------------------------------
void setup() {
  // Bootloader-sicher: D0/D1 werden nicht verwendet. Motor sofort AUS.
  pinMode(PIN_MOTOR_LPWM, OUTPUT);
  pinMode(PIN_MOTOR_RPWM, OUTPUT);
  pinMode(PIN_MOTOR_ENABLE, OUTPUT);
  analogWrite(PIN_MOTOR_LPWM, 0);
  analogWrite(PIN_MOTOR_RPWM, 0);
  digitalWrite(PIN_MOTOR_ENABLE, LOW);

  pinMode(PIN_SYS_ENABLE, INPUT_PULLUP);
  pinMode(PIN_STATUS_LED, OUTPUT);
  pinMode(PIN_D8_RESERVE, INPUT_PULLUP);

  pinMode(PIN_ENC1_CLK, INPUT_PULLUP);
  pinMode(PIN_ENC1_DT, INPUT_PULLUP);
  pinMode(PIN_ENC1_SW, INPUT_PULLUP);
  pinMode(PIN_ENC2_CLK, INPUT_PULLUP);
  pinMode(PIN_ENC2_DT, INPUT_PULLUP);
  pinMode(PIN_ENC2_SW, INPUT_PULLUP);

  loadConfig();

  Wire.begin();
  Wire.setClock(100000UL); // stabil fuer LCD + RTC + MMC5603 am Nano
  delay(100);
  lcd.init();
  delay(50);
  lcd.backlight();
  delay(50);
  lcdReady = true;
  lcdBacklightOn = true;
  lcdInvalidate();
  startText();

  rtcOk = rtc.begin();
  if (rtcOk && rtc.lostPower()) {
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }

  compassOk = mmc.begin(MMC56X3_DEFAULT_ADDRESS, &Wire);

  enc1Prev = readEncState(PIN_ENC1_CLK, PIN_ENC1_DT);
  enc2Prev = readEncState(PIN_ENC2_CLK, PIN_ENC2_DT);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC1_CLK), enc1ISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC2_CLK), enc2ISR, CHANGE);

  lastUserMs = millis();
  lastGoodMoveMs = millis();
}

void loop() {
  readLightSensor();
  updateLightGate();

  if (compassOk) compassOk = readCompass();
  else compassOk = mmc.begin(MMC56X3_DEFAULT_ADDRESS, &Wire);

  if (rtcOk) {
    DateTime dt = rtc.now();
    targetDeg = calcSolarAzimuth(dt);
    errorDeg = angleDiff(targetDeg, headingDeg);
  }

  handleMenu();

  if (inMenu) {
    statusCode = ST_MENU;
    resetTracking();
  } else {
    updateTracking();
  }

  updateMotorRamp();
  renderDisplay();
  updateBacklightTimeout();
  updateStatusLed();
}
